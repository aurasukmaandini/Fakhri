<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

  <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
  <!-- MY CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/style.css">

  <title><?php echo $judul ?></title>
    <style>
      .nav
      {
        background-color: #ffff;
        padding: 7px;
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        width:auto;
        height:auto;
        display: block;
      }
      .pengaturan
      {
        border:0px;
      }
      .mulai
      {
        border-radius: 4px;
        border: 1px solid #f93;
        line-height: 1.5em;
        width:60px;
        height:30px;
        background-color: #ffff;
      }
      .mul
      {
        color:#ff9933;
      }
      .pencarian
      {
        margin-bottom:10px;
        width:30px;
        height:40px;
      }
    </style>
</head>

<body>
  <nav class="nav navbar-expand-lg navbar-light bg-transparant">
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="nav justify-content-end ml-auto">
        <div>
          <li><a class="pengaturan" href="<?= base_url() ?>Home/pengaturan" style="color:#A4A090;">Pengaturan</a>
            <img class="img-fluid" src="<?php echo base_url(); ?>assets/image/setting.png" style="width:30px;">
              <a class="mulai1" href="#"><button class="mulai" type="submit" value="mulai"><span class="mul"><b>Mulai</b></span></button></a>
          </li>
        </div>
      </ul>
    </div>
  </nav>
</body>
