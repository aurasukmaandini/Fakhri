<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

  <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

  <!-- MY CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/style.css">

  <title><?php echo $judul ?></title>
    <style>
      .nav
      {
        background-color: #ffff;
        padding: 7px;
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        width:auto;
        height:auto;
        display: block;
      }
      .pengaturan
      {
        border:0px;
      }
      .mulai
      {
        border-radius: 4px;
        border: 1px solid #f93;
        line-height: 1.5em;
        width:60px;
        height:30px;
        background-color: #ffff;
      }
      .mul
      {
        color:#ff9933;
      }
      .pencarian
      {
        margin-bottom:10px;
        width:30px;
        height:40px;
      }

      .sidenav 
      {
        height: 100%;
        width: 0;
        position: fixed;
        z-index: 1;
        top: 0;
        right: 0;
        background-color: #EFEFE5;
        overflow-x: hidden;
        transition: 0.5s;
        padding-top: 60px;
      }

      .sidenav a
      {
        padding: 8px 8px 8px 32px;
        text-decoration: none;
        font-size: 25px;
        color: #818181;
        display: block;
        transition: 0.3s;
      }

      .sidenav a:hover 
      {
        color: #f1f1f1;
      }

      .sidenav .closebtn 
      {
        position: absolute;
        top: 0;
        left:0px;
        font-size: 36px;
      }

      #home 
      {
        transition: margin-right .5s;
        padding: 16px;
      }

      @media screen and (max-height: 450px) 
      {
        .sidenav {padding-top: 15px;}
        .sidenav a {font-size: 18px;}
      }
    </style>
  </head>

<body id="home">
<nav class="nav navbar-expand-lg navbar-light bg-transparant">
  <div class="collapse navbar-collapse">
    <ul class="nav justify-content-end ml-auto">
    <div class="atas">
      <li>
        <a class="tulisresep" href="#" style="color: #8BAD00">Tulis Resep</a>
        <img class="img-fluid" src="<?php echo base_url(); ?>assets/image/tulis.png" style="width:40px; padding-right:15px;">
        <a class="notifikasi" href="#" style="color: #A3A090">Notifikasi</a>
        <img class="img-fluid" src="<?php echo base_url(); ?>assets/image/lonceng.png" style="width:40px; padding-right:15px;">
        <div id="mySidenav" class="sidenav">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <a class="pengaturan" href="<?= base_url() ?>Home/pengaturan" style="color:#A4A090;"><img class="img-fluid" src="<?php echo base_url(); ?>assets/image/setting.png" style="width:30px; float:right;"></a>
          <a href="#"><h5>Resep</h5></a>
          <div class="Pencarian">
          <form action="linknya" method="post">
            <div class="nyari input-group">
              <input class="form-control form-fluid" type="text" placeholder="Cari resep" name="keyword" style="width:10px; height:40px;"> 
              <div class="input-group-append">
              </div>
            </div>
          </form>
        </div>  
        </div>
        <span style="font-size:20px;cursor:pointer; color:#A3A090;" onclick="openNav()"> menu &#9776;</span>
    </div>
    <script>
    function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("home").style.marginRight = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("home").style.margin= "0";
}
    </script>
    
    </ul>
  </div>
</nav>
</body>
