<?php

class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('resep_model');
	}
	public function index()
	{
		$data['judul'] = 'Cookpad';
		//$data['resep'] = $this->resep_model->getALLResep();
		$this->load->view('templates/header', $data);
		$this->load->view('home/index', $data);
		$this->load->view('templates/footer');
	}

	public function  pengaturan()
    {
    	$data['judul']= 'Form Membuat Akun';
    	$this->load->view('templates/header', $data);
        $this->load->view('home/index_pengaturan');
        $this->load->view('templates/footer');
	}
	public function  Tempe()
    {
    	$data['judul']= 'Form Tempe';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung pangki');
        $this->load->view('templates/footer');
	}
	public function  Cumi_Basah()
    {
    	$data['judul']= 'Form Cumi_Basah';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung pangki');
        $this->load->view('templates/footer');
	}
	public function  Jagung_Rebus()
    {
    	$data['judul']= 'Form Jagung_Rebus';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung pangki');
        $this->load->view('templates/footer');
	}
	public function  Laras_Utami()
    {
    	$data['judul']= 'Form Laras_Utami';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung dini');
        $this->load->view('templates/footer');
	}
	public function  Rizki()
    {
    	$data['judul']= 'Form Rizki';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung dini');
        $this->load->view('templates/footer');
	}
	public function  Nurita()
    {
    	$data['judul']= 'Form Nurita';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung dini');
        $this->load->view('templates/footer');
	}
	public function  Susanti()
    {
    	$data['judul']= 'Form Susanti';
    	$this->load->view('templates/header');
        $this->load->view('home/tergantung dini');
        $this->load->view('templates/footer');
    }
	public function cari()
	{
		$data['judul']= 'Form cari';
		$this->load->view('templates/header');
		if( $this->input->post('keyword'))
		{
        	$data['pangki'] =  $this->resep_model->cariResep();
        }
    }

}
?>