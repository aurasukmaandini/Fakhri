<?php 

class resep_model extends CI_model{
    public function getALLResep()
    {
        return $this->db->get('resep')->result_array();
    }

    //public function cariResep()
    //{
        //$keyword = $this->input->post('keyword', true)
        //$this->like('nama_resep', $keyword);
        //return $this->db->get('resep')->resutl_array();
    //}
    
}
?>